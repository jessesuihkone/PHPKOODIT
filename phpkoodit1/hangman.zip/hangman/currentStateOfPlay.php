
<div class="text-center">
        <h1><?php echo $currentStateOfPlay; ?></h1>
    </div>
