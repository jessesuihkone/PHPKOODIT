<?php
    session_start();
    echo "Olet kirjautunut sisään ". $_SESSION["username"];

?>